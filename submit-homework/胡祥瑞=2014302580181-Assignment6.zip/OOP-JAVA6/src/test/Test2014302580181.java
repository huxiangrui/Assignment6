package test;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Gui.LoginGui2014302580181;
import Gui.MainGui2014302580181;
import pojo.Login2014302580181;
import pojo.Petsql2014302580181;
public class Test2014302580181 {
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost/3306/sid";
	static final String USER = "root";
	static final String PASS = "hxr123";
	static Connection conn = null;
	static Statement stat = null;
	static ResultSet resu =null;
	private String name;
	private String password;
    public static Connection getConnection() throws ClassNotFoundException {
	            Class.forName("com.mysql.jdbc.Driver");
	            try {
					conn=DriverManager.getConnection(DB_URL,USER,PASS);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	            return conn;
    }
    
	   public static void main(String[] args) {
		   try {
			    String SQL = ""; 
			    conn = DriverManager.getConnection(DB_URL);
			    stat = conn.createStatement();
			    resu=stat.executeQuery(SQL); 
             int i=1;
             String[] array=new String[100];
			    while(resu.next()){
			    	String resul=resu.getString(i); 
                 array[i-1]=resul;
                 i++;
             }
             resu.close(); 
             conn.close();    
             } catch (SQLException e) {
             	System.out.println("Error:"+e.toString()+e.getMessage());
             }
		 } 
}
