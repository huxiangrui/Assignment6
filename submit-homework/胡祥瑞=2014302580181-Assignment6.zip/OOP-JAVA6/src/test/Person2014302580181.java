package test;

import java.util.Set;

public class Person2014302580181 {
	private String id;//身份证ID
	private int account;//账号money
	private int age;//年龄
	private Set<String> hobby; //爱好
	private String name;//姓名
	private String sex;//性别
	
	String getId() {
		return id;
	}
	protected int getAccount() {
		return account;
	}
	public int getAge() {
		return age;
	}
	public Set<String> getHobby() {
		return hobby;
	}
	public String getName() {
		return name;
	}
	public String getSex() {
		return sex;
	}
	
	
	
	
}
