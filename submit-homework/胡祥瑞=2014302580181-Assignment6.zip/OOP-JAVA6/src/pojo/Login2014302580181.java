package pojo;
public class Login2014302580181 {
	private String name;
	private String password;
	public String getname()
	{
		return name;
	}
	public String password()
	{
		return password;
	}
	public boolean login(String name,String password)
	{
		if(name==null||password==null)
		{
			return false;
		}
		return true;
	}

}
