package pojo;

import java.util.Map;

public class Cart2014302580181 {
	private int id;
	private Map<Integer,Integer> list;//(id,number)

	public int getId() {
		return id;
	}

	public Map<Integer, Integer> getList() {
		return list;
	}

	public void setList(Map<Integer, Integer> list) {
		this.list = list;
	}
	
}
