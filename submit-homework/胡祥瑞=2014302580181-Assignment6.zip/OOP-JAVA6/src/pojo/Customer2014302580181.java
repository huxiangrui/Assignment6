package pojo;


public class Customer2014302580181 {
	private int id;//id
	private String iid;//身份证ID
	private int account;//账号money
	private String name;//姓名
	private String sex;//性别
	private int phoneNumber;//电话号码
	private String Email;//邮箱
	private Cart2014302580181 myCart;//购物�?
	
	
	public int getId() {
		return id;
	}
	public String getIid() {
		return iid;
	}
	public void setIid(String iid) {
		this.iid = iid;
	}
	public int getAccount() {
		return account;
	}
	public void setAccount(int account) {
		this.account = account;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public Cart2014302580181 getMyCart() {
		return myCart;
	}
	public void setMyCart(Cart2014302580181 myCart) {
		this.myCart = myCart;
	}
	
}
