package pojo;

import java.util.Set;

public class Goods2014302580181 {
	private int id;
	private Pet2014302580181 pet;
	private int number;
	private float price;
	private int inventory;
	private Set<Comment2014302580181> comments;
	
	public int getId() {
		return id;
	}
	public Pet2014302580181 getPet() {
		return pet;
	}
	public void setPet(Pet2014302580181 pet) {
		this.pet = pet;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getInventory() {
		return inventory;
	}
	public void setInventory(int inventory) {
		this.inventory = inventory;
	}
	public Set<Comment2014302580181> getComments() {
		return comments;
	}
	public void setComments(Set<Comment2014302580181> comments) {
		this.comments = comments;
	}
	
}
