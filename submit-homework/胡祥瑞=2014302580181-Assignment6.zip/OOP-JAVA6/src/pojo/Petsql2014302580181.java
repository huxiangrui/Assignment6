package pojo;
import java.sql.*;

public class Petsql2014302580181 {
	public String sql;
    public String JDBC_DRIVER;
    public String DB_URL;
    public String username;
    public String password;
    public Statement stat;
	public ResultSet resu;
    public Connection conn;
    public String getSql()
    {
    	return sql;
    }
    public String getJDBC_DRIVER()
    {
    	return JDBC_DRIVER;
    }
    public String getDB_URL()
    {
    	return DB_URL;
    }
    public String getUsername()
    {
    	return username;
    }
    public String getPassword()
    {
    	return password;
    }
    public Statement getStatement()
    {
    	return stat;
    }
    public ResultSet getResultSet()
    {
    	return resu;
    }
    public Connection getConnection()
    {
    	return conn;
    }
    public void setSql(String sql)
    {
    	this.sql=sql;
    }
    public void setJDBC_DRIVER(String JDBC_DRIVER)
    {
    	this.JDBC_DRIVER=JDBC_DRIVER;
    }
    public void setDB_URL(String DB_URL)
    {
    	this.DB_URL=DB_URL;
    }
    public void setUsername(String username)
    {
    	this.username=username;
    }
    public void setPassword(String password)
    {
    	this.password=password;
    }
    public void setStatement(Statement stat)
    {
    	this.stat=stat;
    }
    public void setResultSet(ResultSet resu)
    {
    	this.resu=resu;
    }
    public void setConnection(Connection conn)
    {
    	this.conn=conn;
    }
}
