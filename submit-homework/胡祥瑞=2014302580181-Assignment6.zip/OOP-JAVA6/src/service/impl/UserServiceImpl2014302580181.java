package service.impl;

import pojo.Customer2014302580181;
import service.inter.IUserService2014302580181;

public class UserServiceImpl2014302580181 implements IUserService2014302580181{

	@Override
	public boolean login(String name, String password) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean register(Customer2014302580181 customer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean checkMail(int uid, String email) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean logout(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getBackPwd(String email) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBackPwd(int phoneNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean add(Customer2014302580181 e) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Customer2014302580181 e) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean query(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean queryAll() {
		// TODO Auto-generated method stub
		return false;
	}

}
