package service.inter;

public interface IBaseService2014302580181<E extends Object> {
	abstract boolean add(E e);
	abstract boolean delete(int id);
	abstract boolean update(E e);
	abstract boolean query(int id);
	abstract boolean queryAll();
}
