package service.inter;

import pojo.Customer2014302580181;

public interface IUserService2014302580181 extends IBaseService2014302580181<Customer2014302580181>{
	public boolean login(String name,String password);
	public boolean register(Customer2014302580181 customer);
	public boolean checkMail(int uid,String email);
	public boolean logout(int id);
	public String getBackPwd(String email);
	public String getBackPwd(int phoneNumber);
}
