package Gui;
import java.awt.FlowLayout;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
@SuppressWarnings("serial")
public class LoginGui2014302580181 extends JFrame{
	private JPanel contentPane ;
	private JLabel UserLabel;
	private JTextField UserTextField;
	private JLabel PasswordLabel;
	private JTextField PasswordTextField;
	private JButton LoginButton;
	private String name;
	private String password;
	private boolean visible;
	public JPanel contentPane(){
		contentPane=new JPanel();
		contentPane.setBorder(new EmptyBorder(10,10,10,10));
		return contentPane;
	}
	public JLabel UserLabel(){
		UserLabel=new JLabel("�û���",200);
		return UserLabel;
	}
	public JTextField UserTextField()
	{
		UserTextField=new JTextField(600);
		return UserTextField;
	}
	public String getUserTextField()
	{
		name=UserTextField.getText();
		return name;
	}
	public JLabel PasswordLabel()
	{
		PasswordLabel=new JLabel("����",200);
		return PasswordLabel;
	}
	public JTextField PasswordTextField()
	{
		PasswordTextField=new JTextField(600);
		return PasswordTextField;
	}
	public String getPasswordTextField()
	{
		password=PasswordTextField.getText();
		return password;
	}
	public JButton LoginButton()
	{
		LoginButton=new JButton("��¼");
		return LoginButton;
	}
	public boolean Visible(boolean visible)
	{
		return visible;
	}
	public LoginGui2014302580181()
	{
		this.setTitle("��¼");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(100, 100, 1100, 1100);
		this.setContentPane(contentPane);
		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER,5,5));
		contentPane.add(UserLabel);
		contentPane.add(UserTextField);
		contentPane.add(PasswordLabel);
		contentPane.add(PasswordTextField);
		contentPane.add(LoginButton);
		this.setVisible(Visible(visible));
	}
}
