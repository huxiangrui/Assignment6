package Gui;
import java.awt.FlowLayout;
import java.util.Set;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

@SuppressWarnings("serial")
public class MainGui2014302580181 extends JFrame {
	private JPanel contentPane ;
	private JLabel label0;
	private JLabel label1;
	private JLabel label2;
	private JLabel label3;
	private JLabel label4;
	private JLabel label5;
	private JCheckBox checkbox1;
	private JCheckBox checkbox2;
	private JCheckBox checkbox3;
	private JCheckBox checkbox4;
	private JCheckBox checkbox5;
	private JCheckBox checkbox6;
	private JCheckBox checkbox7;
	private JCheckBox checkbox8;
	private JCheckBox checkbox9;
	private JCheckBox checkbox10;
	private JCheckBox checkbox11;
	private JLabel labelpetname1;
	private JLabel labelpetname2;
	private JLabel labelpetname3;
	private JLabel labelpetname4;
	private JLabel labelpetname5;
	private JLabel labelpetname6;
	private JLabel labelpetname7;
	private JLabel labelpetname8;
	private JLabel labelpetname9;
	private JLabel labelpetname10;
	private JLabel labelpetname11;
	private JLabel labelpeteat1;
	private JLabel labelpeteat2;
	private JLabel labelpeteat3;
	private JLabel labelpeteat4;
	private JLabel labelpeteat5;
	private JLabel labelpeteat6;
	private JLabel labelpeteat7;
	private JLabel labelpeteat8;
	private JLabel labelpeteat9;
	private JLabel labelpeteat10;
	private JLabel labelpeteat11;
	private JLabel labelpetdrink1;
	private JLabel labelpetdrink2;
	private JLabel labelpetdrink3;
	private JLabel labelpetdrink4;
	private JLabel labelpetdrink5;
	private JLabel labelpetdrink6;
	private JLabel labelpetdrink7;
	private JLabel labelpetdrink8;
	private JLabel labelpetdrink9;
	private JLabel labelpetdrink10;
	private JLabel labelpetdrink11;
	private JLabel labelpetlive1;
	private JLabel labelpetlive2;
	private JLabel labelpetlive3;
	private JLabel labelpetlive4;
	private JLabel labelpetlive5;
	private JLabel labelpetlive6;
	private JLabel labelpetlive7;
	private JLabel labelpetlive8;
	private JLabel labelpetlive9;
	private JLabel labelpetlive10;
	private JLabel labelpetlive11;
	private JLabel labelpethobby1;
	private JLabel labelpethobby2;
	private JLabel labelpethobby3;
	private JLabel labelpethobby4;
	private JLabel labelpethobby5;
	private JLabel labelpethobby6;
	private JLabel labelpethobby7;
	private JLabel labelpethobby8;
	private JLabel labelpethobby9;
	private JLabel labelpethobby10;
	private JLabel labelpethobby11;
	private boolean visible;
	private String petname1;
	private String petname2;
	private String petname3;
	private String petname4;
	private String petname5;
	private String petname6;
	private String petname7;
	private String petname8;
	private String petname9;
	private String petname10;
	private String petname11;
	private String peteat1;
	private String peteat2;
	private String peteat3;
	private String peteat4;
	private String peteat5;
	private String peteat6;
	private String peteat7;
	private String peteat8;
	private String peteat9;
	private String peteat10;
	private String peteat11;
	private String petdrink1;
	private String petdrink2;
	private String petdrink3;
	private String petdrink4;
	private String petdrink5;
	private String petdrink6;
	private String petdrink7;
	private String petdrink8;
	private String petdrink9;
	private String petdrink10;
	private String petdrink11;
	private String petlive1;
	private String petlive2;
	private String petlive3;
	private String petlive4;
	private String petlive5;
	private String petlive6;
	private String petlive7;
	private String petlive8;
	private String petlive9;
	private String petlive10;
	private String petlive11;
	private Set<String> pethobby1;
	private Set<String> pethobby2;
	private Set<String> pethobby3;
	private Set<String> pethobby4;
	private Set<String> pethobby5;
	private Set<String> pethobby6;
	private Set<String> pethobby7;
	private Set<String> pethobby8;
	private Set<String> pethobby9;
	private Set<String> pethobby10;
	private Set<String> pethobby11;
	private String hobby1;
	private String hobby2;
	private String hobby3;
	private String hobby4;
	private String hobby5;
	private String hobby6;
	private String hobby7;
	private String hobby8;
	private String hobby9;
	private String hobby10;
	private String hobby11;
	public String getpetname1()
	{
		return petname1;
	}
	public String getpetname2()
	{
		return petname2;
	}	
	public String getpetname3()
	{
		return petname3;
	}		
	public String getpetname4()
	{
		return petname4;
	}
	public String getpetname5()
	{
		return petname5;
	}	
	public String getpetname6()
	{
		return petname6;
	}	
	public String getpetname7()
	{
		return petname7;
	}		
	public String getpetname8()
	{
		return petname8;
	}	
	public String getpetname9()
	{
		return petname9;
	}	
	public String getpetname10()
	{
		return petname10;
	}
	public String getpetname11()
	{
		return petname11;
	}
	public String getpeteat1()
	{
		return peteat1;
	}	
	public String getpeteat2()
	{
		return peteat2;
	}
	public String getpeteat3()
	{
		return peteat3;
	}
	public String getpeteat4()
	{
		return peteat4;
	}
	public String getpeteat5()
	{
		return peteat5;
	}
	public String getpeteat6()
	{
		return peteat6;
	}
	public String getpeteat7()
	{
		return peteat7;
	}
	public String getpeteat8()
	{
		return peteat8;
	}
	public String getpeteat9()
	{
		return peteat9;
	}
	public String getpeteat10()
	{
		return peteat10;
	}
	public String getpeteat11()
	{
		return peteat11;
	}
	public String getpetdrink1()
	{
		return petdrink1;
	}
	public String getpetdrink2()
	{
		return petdrink2;
	}
	public String getpetdrink3()
	{
		return petdrink3;
	}
	public String getpetdrink4()
	{
		return petdrink4;
	}
	public String getpetdrink5()
	{
		return petdrink5;
	}
	public String getpetdrink6()
	{
		return petdrink6;
	}
	public String getpetdrink7()
	{
		return petdrink7;
	}
	public String getpetdrink8()
	{
		return petdrink8;
	}
	public String getpetdrink9()
	{
		return petdrink9;
	}
	public String getpetdrink10()
	{
		return petdrink10;
	}
	public String getpetdrink11()
	{
		return petdrink11;
	}
	public String getpetlive1()
	{
		return petlive1;
	}
	public String getpetlive2()
	{
		return petlive2;
	}
	public String getpetlive3()
	{
		return petlive3;
	}
	public String getpetlive4()
	{
		return petlive4;
	}
	public String getpetlive5()
	{
		return petlive5;
	}
	public String getpetlive6()
	{
		return petlive6;
	}
	public String getpetlive7()
	{
		return petlive7;
	}
	public String getpetlive8()
	{
		return petlive8;
	}
	public String getpetlive9()
	{
		return petlive9;
	}
	public String getpetlive10()
	{
		return petlive10;
	}
	public String getpetlive11()
	{
		return petlive11;
	}
	public String getpethobby1() 
	{
		hobby1=pethobby1.toString();
		return hobby1;
	}
	public String getpethobby2() 
	{
		hobby2=pethobby2.toString();
		return hobby2;
	}
	public String getpethobby3() 
	{
		hobby3=pethobby3.toString();
		return hobby3;
	}
	public String getpethobby4() 
	{
		hobby4=pethobby4.toString();
		return hobby4;
	}
	public String getpethobby5() 
	{
		hobby5=pethobby5.toString();
		return hobby5;
	}
	public String getpethobby6() 
	{
		hobby6=pethobby6.toString();
		return hobby6;
	}
	public String getpethobby7() 
	{
		hobby7=pethobby7.toString();
		return hobby7;
	}
	public String getpethobby8() 
	{
		hobby8=pethobby8.toString();
		return hobby8;
	}
	public String getpethobby9() 
	{
		hobby9=pethobby9.toString();
		return hobby9;
	}
	public String getpethobby10() 
	{
		hobby10=pethobby10.toString();
		return hobby10;
	}
	public String getpethobby11() 
	{
		hobby11=pethobby11.toString();
		return hobby11;
	}
	public JPanel contentPane(){
		contentPane=new JPanel();
		contentPane.setBorder(new EmptyBorder(10,10,10,10));
		return contentPane;
	}
	public JLabel Label0()
	{
		label0=new JLabel("ѡ��",100);
		return label0;
	}
	public JLabel Label1()
	{
		label1=new JLabel("������",100);
		return label1;
	}
	public JLabel Label2()
	{
		label2=new JLabel("ʳ��",100);
		return label2;
	}
	public JLabel Label3()
	{
		label3=new JLabel("��Ʒ",100);
		return label3;
	}
	public JLabel Label4()
	{
		label4=new JLabel("����",100);
		return label4;
	}
	public JLabel Label5()
	{
		label5=new JLabel("����",100);
		return label5;
	}
	public JCheckBox CheckBox1()
	{
		checkbox1=new JCheckBox();
		return checkbox1;
	}
	public JCheckBox CheckBox2()
	{
		checkbox2=new JCheckBox();
		return checkbox2;
	}
	public JCheckBox CheckBox3()
	{
		checkbox3=new JCheckBox();
		return checkbox3;
	}
	public JCheckBox CheckBox4()
	{
		checkbox4=new JCheckBox();
		return checkbox4;
	}
	public JCheckBox CheckBox5()
	{
		checkbox5=new JCheckBox();
		return checkbox5;
	}
	
	public JCheckBox CheckBox6()
	{
		checkbox6=new JCheckBox();
		return checkbox6;
	}
	public JCheckBox CheckBox7()
	{
		checkbox7=new JCheckBox();
		return checkbox7;
	}
	public JCheckBox CheckBox8()
	{
		checkbox8=new JCheckBox();
		return checkbox8;
	}
	public JCheckBox CheckBox9()
	{
		checkbox9=new JCheckBox();
		return checkbox9;
	}
	public JCheckBox CheckBox10()
	{
		checkbox10=new JCheckBox();
		return checkbox10;
	}
	public JCheckBox CheckBox11()
	{
		checkbox11=new JCheckBox();
		return checkbox11;
	}
	public JLabel Labelpetname1()
	{
		labelpetname1=new JLabel(petname1,100);
		return labelpetname1;
	}
	public JLabel Labelpetname2()
	{
		labelpetname2=new JLabel(petname2,100);
		return labelpetname2;
	}
	public JLabel Labelpetname3()
	{
		labelpetname3=new JLabel(petname3,100);
		return labelpetname3;
	}
	public JLabel Labelpetname4()
	{
		labelpetname4=new JLabel(petname4,100);
		return labelpetname4;
	}
	public JLabel Labelpetname5()
	{
		labelpetname5=new JLabel(petname5,100);
		return labelpetname5;
	}
	
	public JLabel Labelpetname6()
	{
		labelpetname6=new JLabel(petname6,100);
		return labelpetname6;
	}
	public JLabel Labelpetname7()
	{
		labelpetname7=new JLabel(petname7,100);
		return labelpetname7;
	}
	public JLabel Labelpetname8()
	{
		labelpetname8=new JLabel(petname8,100);
		return labelpetname8;
	}
	public JLabel Labelpetname9()
	{
		labelpetname9=new JLabel(petname9,100);
		return labelpetname9;
	}
	public JLabel Labelpetname10()
	{
		labelpetname10=new JLabel(petname10,100);
		return labelpetname10;
	}
	public JLabel Labelpetname11()
	{
		labelpetname11=new JLabel(petname11,100);
		return labelpetname11;
	}
	public JLabel Labelpeteat1()
	{
		labelpeteat1=new JLabel(peteat1,100);
		return labelpeteat1;
	}
	public JLabel Labelpeteat2()
	{
		labelpeteat2=new JLabel(peteat2,100);
		return labelpeteat2;
	}
	public JLabel Labelpeteat3()
	{
		labelpeteat3=new JLabel(peteat3,100);
		return labelpeteat3;
	}
	public JLabel Labelpeteat4()
	{
		labelpeteat2=new JLabel(peteat4,100);
		return labelpeteat4;
	}
	public JLabel Labelpeteat5()
	{
		labelpeteat5=new JLabel(peteat5,100);
		return labelpeteat5;
	}
	public JLabel Labelpeteat6()
	{
		labelpeteat6=new JLabel(peteat6,100);
		return labelpeteat6;
	}
	
	public JLabel Labelpeteat7()
	{
		labelpeteat7=new JLabel(peteat7,100);
		return labelpeteat7;
	}
	public JLabel Labelpeteat8()
	{
		labelpeteat8=new JLabel(peteat8,100);
		return labelpeteat8;
	}public JLabel Labelpeteat9()
	{
		labelpeteat1=new JLabel(peteat9,100);
		return labelpeteat9;
	}
	public JLabel Labelpeteat10()
	{
		labelpeteat10=new JLabel(peteat10,100);
		return labelpeteat10;
	}
	public JLabel Labelpeteat11()
	{
		labelpeteat11=new JLabel(peteat11,100);
		return labelpeteat11;
	}
	public JLabel Labelpetdrink1()
	{
		labelpetdrink1=new JLabel(petdrink1,100);
		return labelpetdrink1;
	}
	public JLabel Labelpetdrink2()
	{
		labelpetdrink2=new JLabel(petdrink2,100);
		return labelpetdrink2;
	}
	public JLabel Labelpetdrink3()
	{
		labelpetdrink3=new JLabel(petdrink3,100);
		return labelpetdrink3;
	}
	public JLabel Labelpetdrink4()
	{
		labelpetdrink4=new JLabel(petdrink4,100);
		return labelpetdrink4;
	}
	
	public JLabel Labelpetdrink5()
	{
		labelpetdrink5=new JLabel(petdrink5,100);
		return labelpetdrink5;
	}
	public JLabel Labelpetdrink()
	{
		labelpetdrink6=new JLabel(petdrink6,100);
		return labelpetdrink6;
	}
	public JLabel Labelpetdrink7()
	{
		labelpetdrink7=new JLabel(petdrink7,100);
		return labelpetdrink7;
	}
	public JLabel Labelpetdrink8()
	{
		labelpetdrink8=new JLabel(petdrink8,100);
		return labelpetdrink8;
	}
	public JLabel Labelpetdrink9()
	{
		labelpetdrink9=new JLabel(petdrink9,100);
		return labelpetdrink9;
	}
	public JLabel Labelpetdrink10()
	{
		labelpetdrink10=new JLabel(petdrink10,100);
		return labelpetdrink10;
	}
	public JLabel Labelpetdrink11()
	{
		labelpetdrink11=new JLabel(petdrink11,100);
		return labelpetdrink11;
	}
	public JLabel Labelpetlive1()
	{
		labelpetlive1=new JLabel(petlive1,100);
		return labelpetlive1;
	}
	public JLabel Labelpetlive2()
	{
		labelpetlive2=new JLabel(petlive2,100);
		return labelpetlive2;
	}
	public JLabel Labelpetlive3()
	{
		labelpetlive3=new JLabel(petlive3,100);
		return labelpetlive3;
	}
	public JLabel Labelpetlive4()
	{
		labelpetlive4=new JLabel(petlive4,100);
		return labelpetlive4;
	}
	public JLabel Labelpetlive5()
	{
		labelpetlive5=new JLabel(petlive5,100);
		return labelpetlive5;
	}
	public JLabel Labelpetlive6()
	{
		labelpetlive6=new JLabel(petlive6,100);
		return labelpetlive6;
	}
	public JLabel Labelpetlive7()
	{
		labelpetlive7=new JLabel(petlive7,100);
		return labelpetlive7;
	}
	public JLabel Labelpetlive8()
	{
		labelpetlive8=new JLabel(petlive8,100);
		return labelpetlive8;
	}
	public JLabel Labelpetlive9()
	{
		labelpetlive9=new JLabel(petlive9,100);
		return labelpetlive9;
	}
	public JLabel Labelpetlive10()
	{
		labelpetlive10=new JLabel(petlive10,100);
		return labelpetlive10;
	}
	public JLabel Labelpetlive11()
	{
		labelpetlive11=new JLabel(petlive11,100);
		return labelpetlive11;
	}
	public JLabel Labelpethobby1()
	{
		labelpethobby1=new JLabel(hobby1,100);
		return labelpethobby1;
	}
	public JLabel Labelpethobby2()
	{
		labelpethobby2=new JLabel(hobby2,100);
		return labelpethobby2;
	}
	public JLabel Labelpethobby3()
	{
		labelpethobby3=new JLabel(hobby3,100);
		return labelpethobby3;
	}
	public JLabel Labelpethobby4()
	{
		labelpethobby4=new JLabel(hobby4,100);
		return labelpethobby4;
	}
	public JLabel Labelpethobby5()
	{
		labelpethobby5=new JLabel(hobby5,100);
		return labelpethobby5;
	}
	public JLabel Labelpethobby6()
	{
		labelpethobby6=new JLabel(hobby6,100);
		return labelpethobby6;
	}
	public JLabel Labelpethobby7()
	{
		labelpethobby7=new JLabel(hobby7,100);
		return labelpethobby7;
	}public JLabel Labelpethobby8()
	{
		labelpethobby8=new JLabel(hobby8,100);
		return labelpethobby8;
	}
	public JLabel Labelpethobby9()
	{
		labelpethobby9=new JLabel(hobby9,100);
		return labelpethobby9;
	}
	public JLabel Labelpethobby10()
	{
		labelpethobby10=new JLabel(hobby10,100);
		return labelpethobby10;
	}
	public JLabel Labelpethobby11()
	{
		labelpethobby11=new JLabel(hobby11,100);
		return labelpethobby11;
	}
	public boolean Visible(boolean visible)
	{
		return visible;
	}
	public MainGui2014302580181()
	{
		this.setTitle("����");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(100, 100, 1100, 1100);
		this.setContentPane(contentPane);
		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER,5,5));
		contentPane.add(label0);
		contentPane.add(label1);
		contentPane.add(label2);
		contentPane.add(label3);
		contentPane.add(label4);
		contentPane.add(label5);
		contentPane.add(checkbox1);
		contentPane.add(labelpetname1);
		contentPane.add(labelpeteat1);
		contentPane.add(labelpetdrink1);
		contentPane.add(labelpetlive1);
		contentPane.add(labelpethobby1);
		contentPane.add(checkbox2);
		contentPane.add(labelpetname2);
		contentPane.add(labelpeteat2);
		contentPane.add(labelpetdrink2);
		contentPane.add(labelpetlive2);
		contentPane.add(labelpethobby2);
		contentPane.add(checkbox3);
		contentPane.add(labelpetname3);
		contentPane.add(labelpeteat3);
		contentPane.add(labelpetdrink3);
		contentPane.add(labelpetlive3);
		contentPane.add(labelpethobby3);
		contentPane.add(checkbox4);
		contentPane.add(labelpetname4);
		contentPane.add(labelpeteat4);
		contentPane.add(labelpetdrink4);
		contentPane.add(labelpetlive4);
		contentPane.add(labelpethobby4);
		contentPane.add(checkbox5);
		contentPane.add(labelpetname5);
		contentPane.add(labelpeteat5);
		contentPane.add(labelpetdrink5);
		contentPane.add(labelpetlive5);
		contentPane.add(labelpethobby5);
		contentPane.add(checkbox6);
		contentPane.add(labelpetname6);
		contentPane.add(labelpeteat6);
		contentPane.add(labelpetdrink6);
		contentPane.add(labelpetlive6);
		contentPane.add(labelpethobby6);
		contentPane.add(checkbox7);
		contentPane.add(labelpetname7);
		contentPane.add(labelpeteat7);
		contentPane.add(labelpetdrink7);
		contentPane.add(labelpetlive7);
		contentPane.add(labelpethobby7);
		contentPane.add(checkbox8);
		contentPane.add(labelpetname8);
		contentPane.add(labelpeteat8);
		contentPane.add(labelpetdrink8);
		contentPane.add(labelpetlive8);
		contentPane.add(labelpethobby8);
		contentPane.add(checkbox9);
		contentPane.add(labelpetname9);
		contentPane.add(labelpeteat9);
		contentPane.add(labelpetdrink9);
		contentPane.add(labelpetlive9);
		contentPane.add(labelpethobby9);
		contentPane.add(checkbox10);
		contentPane.add(labelpetname10);
		contentPane.add(labelpeteat10);
		contentPane.add(labelpetdrink10);
		contentPane.add(labelpetlive10);
		contentPane.add(labelpethobby10);
		contentPane.add(checkbox11);
		contentPane.add(labelpetname11);
		contentPane.add(labelpeteat11);
		contentPane.add(labelpetdrink11);
		contentPane.add(labelpetlive11);
		contentPane.add(labelpethobby11);
		this.setVisible(Visible(visible));
	}
}
      

